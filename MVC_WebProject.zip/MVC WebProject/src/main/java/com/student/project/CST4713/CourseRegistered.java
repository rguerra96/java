package com.student.project.CST4713;

import com.utility.CST4713.CourseLookUpService;
import com.utility.CST4713.MyDButil;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;

public class CourseRegistered implements CourseLookUpService {

    public CourseRegistered() {
    }

    @Override
    public ArrayList<Student> findAllCourse(String ssn, String username, String password) {
        ArrayList<Student> student = new ArrayList<>();

        String sqlStr = "SELECT course.[courseID]," +
                "    course.[title]," +
                "    student.[firstName]," +
                "    student.[lastName]," +
                "    enroll.[grade]" +
                "FROM [CUNY_DB].[dbo].[Course] AS course" +
                "    JOIN [CUNY_DB].[dbo].[Enrollment] as enroll ON course.courseID = enroll.courseId" +
                "    JOIN [CUNY_DB].[dbo].[Students] as student ON student.ssn = " + ssn;

        if (ssn != null) {
            try (MyDButil dButil = new MyDButil();) {

                ResultSet resultSet = dButil.getQuery(sqlStr, username, password);
                if (resultSet != null)
                    while (resultSet.next()) {
                        student.add(new Student(resultSet.getString(1),
                                resultSet.getString(2),
                                resultSet.getString(3),
                                resultSet.getString(4),
                                resultSet.getString(5),
                                resultSet.getString(5)));
                        System.out.println("Successful login access!");
                    }
                else
                    System.out.println("Student does not exist");


            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
            }
            return student;
        } else
            return null;
    }

    @Override
    public Student findStudent(String ssn, String username, String password) {
        Student student = new Student();
        String sqlStr = "SELECT course.[courseID]," +
                "    course.[title]," +
                "    student.[firstName]," +
                "    student.[lastName]," +
                "    enroll.[grade]," +
                "    student.[ssn]" +
                "FROM [CUNY_DB].[dbo].[Course] AS course" +
                "    JOIN [CUNY_DB].[dbo].[Enrollment] as enroll ON course.courseID = enroll.courseId" +
                "    JOIN [CUNY_DB].[dbo].[Students] as student ON student.ssn = " + ssn;

        if (ssn != null) {
            try (MyDButil dButil = new MyDButil();) {

                ResultSet resultSet = dButil.getQuery(sqlStr, username, password);

                if (resultSet.next()) {
                    student = new Student(resultSet.getString(1),
                            resultSet.getString(2),
                            resultSet.getString(3),
                            resultSet.getString(4),
                            resultSet.getString(5),
                            resultSet.getString(6));
                    System.out.println("Successful login access!");
                }
            } catch (SQLException | ClassNotFoundException e) {
                e.printStackTrace();
            }
            return student;
        } else
            return null;
    }

}
