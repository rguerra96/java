package com.student.project.CST4713;

public class Student {

    private String courseID;
    private String title;
    private String firstName;
    private String lastName;
    private String grade;
    private String ssn;

    public Student(String courseID, String title, String firstName, String lastName, String grade, String ssn) {
        this.courseID = courseID;
        this.title = title;
        this.firstName = firstName;
        this.lastName = lastName;
        this.grade = grade;
        this.ssn = ssn;
    }
    
    public Student(){}

    public String getCourseID() {
        return courseID;
    }

    public String getTitle() {
        return title;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getGrade() {
        return grade;
    }

    public String getSsn() {
        return ssn;
    }

    @Override
    public String toString() {
        return "Student{" +
                "courseID='" + courseID + '\'' +
                ", title='" + title + '\'' +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", grade='" + grade + '\'' +
                ", ssn='" + ssn + '\'' +
                '}' + "\n";
    }

}
