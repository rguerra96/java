package com.utility.CST4713;

import com.student.project.CST4713.Student;

import java.util.ArrayList;

public interface CourseLookUpService {
    ArrayList<Student> findAllCourse(String ssn, String password, String username);
    Student findStudent(String ssn, String username, String password);
}
