package com.student.project.CST4713;

import com.utility.CST4713.CourseLookUpService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/getCourses")
public class GetCourse extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        CourseLookUpService service = new CourseRegistered();
        String ssn = request.getParameter("ssn");
        String password = request.getParameter("password");
        String username = request.getParameter("databaseID");
        HttpSession session = request.getSession();
        session.setAttribute("ssn", ssn);
        session.setAttribute("databaseID", username);
        session.setAttribute("password", password);

        Student student = service.findStudent(ssn, username, password);
        String address;
        if (student.getSsn() != null && student.getSsn().trim().equals(ssn))
            address = "/WEB-INF/CourseRegistered.jsp";
        else
            address = "/WEB-INF/StudentNotFound.jsp";

        request.getServletContext()
                .getRequestDispatcher(address)
                .forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
